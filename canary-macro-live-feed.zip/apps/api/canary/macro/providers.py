"""Data providers: FRED (St. Louis Fed) and U.S. Treasury FiscalData.

Both are free. FRED needs an API key (https://fred.stlouisfed.org/docs/api/api_key.html).
Treasury FiscalData needs no key.

Errors never include the request URL, because the FRED key travels in the query string.
"""
from __future__ import annotations

import asyncio
import datetime as dt
from dataclasses import dataclass

import httpx

FRED_BASE = "https://api.stlouisfed.org/fred"
FISCAL_BASE = "https://api.fiscaldata.treasury.gov/services/api/fiscal_service"
TGA_ACCOUNT = "Treasury General Account (TGA) Closing Balance"


class ProviderError(RuntimeError):
    """A provider call failed. The message is safe to show to users (no keys, no URLs)."""


@dataclass(frozen=True)
class Obs:
    date: dt.date
    value: float


async def _get_json(http: httpx.AsyncClient, url: str, params: dict, label: str, retries: int = 2,
                    headers: dict | None = None) -> dict:
    last = "unknown error"
    for attempt in range(retries + 1):
        try:
            r = await http.get(url, params=params, timeout=20.0, headers=headers)
        except httpx.TransportError as exc:
            last = f"network error ({type(exc).__name__})"
        else:
            if r.status_code == 200:
                try:
                    return r.json()
                except ValueError:
                    last = "response was not JSON"
            elif r.status_code in (429, 500, 502, 503, 504):
                last = f"HTTP {r.status_code}"
            elif r.status_code in (400, 403) and label.startswith("FRED"):
                raise ProviderError(
                    f"{label}: HTTP {r.status_code}. FRED rejected the API key. Check it was copied in full, "
                    "has no spaces, and is the current key at fredaccount.stlouisfed.org/apikeys")
            else:
                raise ProviderError(f"{label}: HTTP {r.status_code}")
        if attempt < retries:
            await asyncio.sleep(0.5 * (2**attempt))
    raise ProviderError(f"{label}: {last}")


def scale_to_billions(units: str) -> float:
    """Multiplier that converts a FRED `units` string to billions of dollars."""
    u = units.lower()
    if "millions" in u:
        return 1 / 1000
    if "billions" in u:
        return 1.0
    if "thousands" in u:
        return 1 / 1_000_000
    if "trillions" in u:
        return 1000.0
    raise ProviderError(f"unexpected FRED units: {units!r}")


class FredClient:
    def __init__(self, api_key: str, http: httpx.AsyncClient):
        api_key = (api_key or "").strip().strip("\"'").strip()
        if not api_key:
            raise ProviderError("FRED_API_KEY is not set")
        if len(api_key) != 32 or not api_key.isalnum():
            raise ProviderError(f"FRED_API_KEY should be 32 letters and digits, but the one given has {len(api_key)} characters")
        self._key = api_key
        self._http = http

    async def observations(self, series_id: str, lookback_days: int = 900) -> list[Obs]:
        start = (dt.date.today() - dt.timedelta(days=lookback_days)).isoformat()
        data = await _get_json(
            self._http,
            f"{FRED_BASE}/series/observations",
            {"series_id": series_id, "api_key": self._key, "file_type": "json",
             "observation_start": start, "sort_order": "asc"},
            f"FRED {series_id}",
        )
        out: list[Obs] = []
        for o in data.get("observations", []):
            try:  # FRED marks missing values with "."
                out.append(Obs(dt.date.fromisoformat(o["date"]), float(o["value"])))
            except (KeyError, ValueError):
                continue
        if not out:
            raise ProviderError(f"FRED {series_id}: no observations")
        out.sort(key=lambda x: x.date)
        return out

    async def units(self, series_id: str) -> str:
        data = await _get_json(
            self._http, f"{FRED_BASE}/series",
            {"series_id": series_id, "api_key": self._key, "file_type": "json"},
            f"FRED {series_id} metadata",
        )
        try:
            return data["seriess"][0]["units"]
        except (KeyError, IndexError):
            raise ProviderError(f"FRED {series_id}: no units in metadata")


async def tga_closing_balance(http: httpx.AsyncClient, lookback_days: int = 150) -> list[Obs]:
    """Daily Treasury General Account closing balance in billions of dollars (FiscalData DTS)."""
    start = (dt.date.today() - dt.timedelta(days=lookback_days)).isoformat()
    data = await _get_json(
        http,
        f"{FISCAL_BASE}/v1/accounting/dts/operating_cash_balance",
        {"fields": "record_date,account_type,open_today_bal,close_today_bal",
         "filter": f"record_date:gte:{start},account_type:eq:{TGA_ACCOUNT}",
         "sort": "record_date", "page[size]": "300"},
        "Treasury DTS",
    )
    out: list[Obs] = []
    for row in data.get("data", []):
        raw = row.get("close_today_bal")
        if raw in (None, "", "null"):
            raw = row.get("open_today_bal")
        try:  # DTS values are in millions of dollars
            out.append(Obs(dt.date.fromisoformat(row["record_date"]), float(raw) / 1000))
        except (KeyError, TypeError, ValueError):
            continue
    if not out:
        raise ProviderError("Treasury DTS: no TGA rows")
    out.sort(key=lambda x: x.date)
    return out


# ---- live market quotes (Yahoo Finance chart endpoint: free, no key, unofficial) ---------------

YF_BASE = "https://query1.finance.yahoo.com/v8/finance/chart"
YF_HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; CANARY-macro/1.0)"}
# symbol, label, decimals
MARKETS = [
    ("DX-Y.NYB", "US dollar index (DXY)", 2),
    ("^GSPC", "S&P 500", 0),
    ("^VIX", "VIX", 2),
    ("^TNX", "US 10-year yield (%)", 3),
    ("GC=F", "Gold (USD/oz)", 0),
    ("BTC-USD", "Bitcoin (USD)", 0),
]


@dataclass(frozen=True)
class Quote:
    symbol: str
    price: float
    prev_close: float
    time: dt.datetime          # when the price was last traded (UTC)
    closes: list[Obs]          # daily closes, oldest first; the last one is today's live price


async def yahoo_quote(http: httpx.AsyncClient, symbol: str) -> Quote:
    label = f"Yahoo {symbol}"
    data = await _get_json(http, f"{YF_BASE}/{symbol}", {"range": "1y", "interval": "1d"}, label,
                           retries=1, headers=YF_HEADERS)
    try:
        res = data["chart"]["result"][0]
        meta = res["meta"]
        price = float(meta["regularMarketPrice"])
        when = dt.datetime.fromtimestamp(int(meta["regularMarketTime"]), dt.timezone.utc)
        stamps = res["timestamp"]
        closes_raw = res["indicators"]["quote"][0]["close"]
    except (KeyError, IndexError, TypeError, ValueError):
        raise ProviderError(f"{label}: unexpected response shape")
    closes = [Obs(dt.datetime.fromtimestamp(t, dt.timezone.utc).date(), float(c))
              for t, c in zip(stamps, closes_raw) if c is not None]
    if len(closes) < 2:
        raise ProviderError(f"{label}: not enough history")
    if closes[-1].date == when.date():
        closes[-1] = Obs(closes[-1].date, price)      # today's bar: use the live price
        prev = closes[-2].value
    else:
        closes.append(Obs(when.date(), price))        # the last bar is an older day; add the live price
        prev = closes[-2].value
    return Quote(symbol, price, prev, when, closes)
