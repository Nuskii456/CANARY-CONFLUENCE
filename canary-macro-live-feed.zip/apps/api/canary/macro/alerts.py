"""Telegram alerts when the macro picture changes.

An alert goes out when, compared with the last alert state:
  - a factor changes direction (tightening, neutral, easing) or moves by 2 or more points
  - the regime changes (for example Split market to Tightening tilt)
  - the big-move trigger changes (Wait, Arm, Go)

The first run only records a baseline, so you are not alerted about the state you already know.
A factor that changed is not alerted again for 12 hours, which stops a score hovering on a threshold from spamming you.
Stale or missing readings never trigger an alert.

Setup: message @BotFather on Telegram, send /newbot, and copy the token. Send any message to your new bot,
then open https://api.telegram.org/bot<TOKEN>/getUpdates and copy "chat":{"id": ...}.
Set TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID. Optional: MACRO_PUBLIC_URL (the link added to each alert).
"""
from __future__ import annotations

import datetime as dt
import json
import logging
import os
from pathlib import Path

import httpx

log = logging.getLogger("canary.macro.alerts")

NAMES = {-2: "Tight++", -1: "Lean tight", 0: "Flat", 1: "Lean ease", 2: "Ease++"}
TRIGGERS = {"wait": "Wait", "arm": "Arm", "go": "Go"}
COOLDOWN = dt.timedelta(hours=12)


def _sign(n: int) -> int:
    return (n > 0) - (n < 0)


class Alerts:
    def __init__(self, data_dir: Path, http: httpx.AsyncClient, token: str | None = None,
                 chat_id: str | None = None, now=None):
        self.path = Path(data_dir) / "macro_alerts.json"
        self._http = http
        self.token = (token if token is not None else os.environ.get("TELEGRAM_BOT_TOKEN", "")).strip()
        self.chat_id = str(chat_id if chat_id is not None else os.environ.get("TELEGRAM_CHAT_ID", "")).strip()
        self.url = os.environ.get("MACRO_PUBLIC_URL", "").strip()
        self._now = now or (lambda: dt.datetime.now(dt.timezone.utc))

    @property
    def configured(self) -> bool:
        return bool(self.token and self.chat_id)

    # ---- state -------------------------------------------------------------------------------
    def _load(self) -> dict | None:
        try:
            return json.loads(self.path.read_text())
        except (OSError, ValueError):
            return None

    def _save(self, state: dict) -> None:
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".tmp")
            tmp.write_text(json.dumps(state))
            os.replace(tmp, self.path)
        except OSError:
            log.exception("could not save alert state")

    # ---- comparison --------------------------------------------------------------------------
    def changes(self, snapshot: dict) -> list[str]:
        """Compare the snapshot with the stored state; update the state; return alert lines."""
        a = snapshot["analysis"]
        live = {f["id"]: f for f in snapshot["factors"]
                if f.get("source") in ("live", "manual") and not f.get("stale")}
        cur = {"scores": {i: f["score"] for i, f in live.items()},
               "regime": a["playbook"]["tag"], "trigger": a["trigger"], "net": a["net"]}
        prev = self._load()
        now = self._now()
        if prev is None:  # first run: baseline only
            self._save({**cur, "at": {}})
            return []
        at = prev.get("at", {})
        state = {"scores": dict(prev["scores"]), "regime": prev["regime"],
                 "trigger": prev["trigger"], "net": prev["net"], "at": dict(at)}
        lines: list[str] = []

        def cooled(key: str) -> bool:
            t = at.get(key)
            return t is None or now - dt.datetime.fromisoformat(t) >= COOLDOWN

        names = {f["id"]: f["name"] for f in snapshot["factors"]}
        for fid, new in cur["scores"].items():
            old = prev["scores"].get(fid)
            if old is None:
                state["scores"][fid] = new  # factor came online; record quietly
            elif (_sign(old) != _sign(new) or abs(old - new) >= 2) and cooled(f"f:{fid}"):
                lines.append(f"{names[fid]}: {NAMES[old]} to {NAMES[new]}")
                state["scores"][fid] = new
                state["at"][f"f:{fid}"] = now.isoformat()
            elif old != new and _sign(old) == _sign(new) and abs(old - new) < 2:
                state["scores"][fid] = new  # same direction: track quietly
        if cur["regime"] != prev["regime"] and cooled("regime"):
            lines.insert(0, f"Regime: {prev['regime']} to {cur['regime']} (net {prev['net']:+.0f} to {cur['net']:+.0f})")
            state["regime"], state["net"] = cur["regime"], cur["net"]
            state["at"]["regime"] = now.isoformat()
        if cur["trigger"] != prev["trigger"] and cooled("trigger"):
            lines.append(f"Big-move trigger: {TRIGGERS.get(prev['trigger'], prev['trigger'])} to "
                         f"{TRIGGERS.get(cur['trigger'], cur['trigger'])}")
            state["trigger"] = cur["trigger"]
            state["at"]["trigger"] = now.isoformat()
        self._save(state)
        return lines

    # ---- sending -----------------------------------------------------------------------------
    async def send(self, text: str) -> bool:
        if not self.configured:
            return False
        if self.url:
            text += f"\n{self.url}"
        try:
            r = await self._http.post(f"https://api.telegram.org/bot{self.token}/sendMessage",
                                      json={"chat_id": self.chat_id, "text": text,
                                            "disable_web_page_preview": True}, timeout=10.0)
        except httpx.HTTPError as exc:  # never log the URL: it contains the bot token
            log.warning("telegram alert failed (%s)", type(exc).__name__)
            return False
        if r.status_code != 200:
            log.warning("telegram alert failed (HTTP %s)", r.status_code)
        return r.status_code == 200

    async def check(self, snapshot: dict) -> list[str]:
        if not self.configured:
            return []
        lines = self.changes(snapshot)
        if lines:
            await self.send("CANARY macro alert\n" + "\n".join(lines))
        return lines
