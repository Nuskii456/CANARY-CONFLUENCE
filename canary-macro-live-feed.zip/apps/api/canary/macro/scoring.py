"""Turn raw series into factor scores from -2 (strong tightening) to +2 (strong easing).

Every function is pure: it takes {series_id: [Obs, ...]} and returns a FactorResult, so the
rules can be tested without any network. Thresholds are judgement calls; change them here.
"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field

from .providers import Obs

Series = dict[str, list[Obs]]


class InsufficientData(Exception):
    pass


@dataclass
class FactorResult:
    id: str
    score: int
    headline: str
    readings: list[tuple[str, str]]
    as_of: dt.date
    max_age_days: int
    source: str = "live"
    notes: list[str] = field(default_factory=list)

    def to_dict(self, today: dt.date) -> dict:
        age = (today - self.as_of).days
        stale = age > self.max_age_days
        return {
            "id": self.id, "score": self.score, "headline": self.headline,
            "readings": [list(r) for r in self.readings], "as_of": self.as_of.isoformat(),
            "age_days": age, "stale": stale,
            "confidence": "Low" if stale else ("Analyst" if self.source == "manual" else "High"),
            "source": self.source, "notes": self.notes,
        }


def clamp(x: float) -> int:
    """Truncate toward zero, then limit to -2..2. Half-points never round up into a stronger signal."""
    return max(-2, min(2, int(x)))


# ---- helpers ---------------------------------------------------------------------------------

def need(S: Series, sid: str, n: int = 1) -> list[Obs]:
    obs = S.get(sid)
    if not obs or len(obs) < n:
        raise InsufficientData(f"{sid}: need {n} observations")
    return obs


def at(obs: list[Obs], d: dt.date) -> Obs | None:
    for o in reversed(obs):
        if o.date <= d:
            return o
    return None


def change(obs: list[Obs], days: int) -> float:
    last = obs[-1]
    prev = at(obs, last.date - dt.timedelta(days=days))
    if prev is None or prev is last:
        raise InsufficientData(f"not enough history for a {days}-day change")
    return last.value - prev.value


def pct(obs: list[Obs], days: int) -> float:
    last = obs[-1]
    prev = at(obs, last.date - dt.timedelta(days=days))
    if prev is None or prev is last or prev.value == 0:
        raise InsufficientData(f"not enough history for a {days}-day % change")
    return (last.value / prev.value - 1) * 100


def yoy(obs: list[Obs]) -> float:
    return pct(obs, 365)


# ---- factors ---------------------------------------------------------------------------------

def monetary(S: Series) -> FactorResult:
    up, lo, dff, y2 = need(S, "DFEDTARU"), need(S, "DFEDTARL"), need(S, "DFF"), need(S, "DGS2")
    spread = y2[-1].value - dff[-1].value  # 2y yield above policy rate = market pricing hikes
    if spread >= 0.50: base = -2
    elif spread >= 0.20: base = -1
    elif spread <= -0.50: base = 2
    elif spread <= -0.20: base = 1
    else: base = 0
    move = change(up, 90)
    score = base
    if move > 0: score = min(base, -1)   # a hike in the last 90 days is never better than "tight"
    elif move < 0: score = max(base, 1)  # a cut in the last 90 days is never worse than "ease"
    pricing = "hikes" if spread >= 0.20 else "cuts" if spread <= -0.20 else "no change"
    return FactorResult(
        "mon", clamp(score),
        f"Policy rate {lo[-1].value:.2f}–{up[-1].value:.2f}%. The 2-year yield is {spread:+.2f} pts from fed funds, so markets are pricing {pricing}.",
        [("Target range", f"{lo[-1].value:.2f}–{up[-1].value:.2f}%"), ("Effective fed funds", f"{dff[-1].value:.2f}%"),
         ("2-year Treasury yield", f"{y2[-1].value:.2f}%"), ("2y minus fed funds", f"{spread:+.2f} pts"),
         ("Target change, 90 days", f"{move:+.2f} pts")],
        max(up[-1].date, y2[-1].date), 5,
    )


def economic_data(S: Series) -> FactorResult:
    pce, cpi, core = need(S, "PCEPILFE", 13), need(S, "CPIAUCSL", 13), need(S, "CPILFESL", 13)
    un, pay = need(S, "UNRATE", 15), need(S, "PAYEMS", 4)
    pce_y, cpi_y, core_y = yoy(pce), yoy(cpi), yoy(core)
    if pce_y >= 3.25: infl = -2
    elif pce_y >= 2.5: infl = -1
    elif pce_y >= 2.0: infl = 0
    else: infl = 1
    pay3 = ((pay[-1].value - pay[-4].value) / 3)  # thousands of jobs per month
    un3 = sum(o.value for o in un[-3:]) / 3
    hist = [o.value for o in un[-15:]]  # 3-month averages ending before the current window
    prior_low = min(sum(hist[i - 3:i]) / 3 for i in range(3, len(hist) - 2))
    sahm = un3 - prior_low  # Sahm-style gap: 0.5 or more signals a weakening labour market
    weak_labour = sahm >= 0.5 or pay3 < 50
    score = clamp(infl + (1 if weak_labour else 0))
    gdp_txt = "n/a"
    if S.get("GDPC1") and len(S["GDPC1"]) >= 2:
        g = ((S["GDPC1"][-1].value / S["GDPC1"][-2].value) ** 4 - 1) * 100
        gdp_txt = f"{g:.1f}% annualised"
    return FactorResult(
        "dat", score,
        f"Core PCE inflation is {pce_y:.1f}% and payrolls average {pay3:+.0f}K a month. "
        + ("Weak labour data could open the door to easing." if weak_labour else "Inflation, not growth, sets the stance."),
        [("Core PCE (y/y)", f"{pce_y:.2f}%"), ("CPI (y/y)", f"{cpi_y:.2f}%"), ("Core CPI (y/y)", f"{core_y:.2f}%"),
         ("Unemployment", f"{un[-1].value:.1f}%"), ("Payrolls, 3-month avg", f"{pay3:+.0f}K"),
         ("Unemployment vs 12m low (3m avg)", f"{sahm:+.2f} pts"), ("Real GDP, last quarter", gdp_txt)],
        max(pce[-1].date, un[-1].date), 65,
    )


def dollar(S: Series) -> FactorResult:
    live = S.get("DXY_LIVE")
    if live and len(live) >= 60:
        d, name, max_age = live, "ICE DXY (live)", 5
        notes = ["Uses the live ICE dollar index from Yahoo Finance."]
    else:
        d, name, max_age = need(S, "DTWEXBGS", 10), "Broad USD index (Fed, DXY proxy)", 7
        notes = ["Live DXY was unavailable, so this uses the Federal Reserve's broad dollar index, which lags by about a week."]
    c = pct(d, 90)
    if c >= 2.0: score = -2
    elif c >= 0.75: score = -1
    elif c <= -2.0: score = 2
    elif c <= -0.75: score = 1
    else: score = 0
    hi = max(o.value for o in d if o.date >= d[-1].date - dt.timedelta(days=365))
    return FactorResult(
        "dxy", score,
        f"The dollar index is {c:+.1f}% over 90 days, {(d[-1].value / hi - 1) * 100:+.1f}% from its 12-month high.",
        [(name, f"{d[-1].value:.2f}"), ("Change, 90 days", f"{c:+.2f}%"),
         ("Change, 30 days", f"{pct(d, 30):+.2f}%"), ("Vs 12-month high", f"{(d[-1].value / hi - 1) * 100:+.2f}%")],
        d[-1].date, max_age, notes=notes,
    )


def money_supply(S: Series) -> FactorResult:
    m = need(S, "M2SL", 14)
    y = yoy(m)
    if y >= 8.0: score = 2
    elif y >= 6.5: score = 1
    elif y <= 0.0: score = -2
    elif y <= 2.5: score = -1
    else: score = 0
    ann3 = ((m[-1].value / m[-4].value) ** 4 - 1) * 100
    return FactorResult(
        "m2", score,
        f"US M2 grew {y:.1f}% over the last year and {ann3:.1f}% annualised over the last three months.",
        [("M2 growth (y/y)", f"{y:.2f}%"), ("M2, 3-month annualised", f"{ann3:.2f}%"),
         ("M2 level", f"${m[-1].value / 1000:.2f}T")],
        m[-1].date, 65,
    )


def _net_liquidity(S: Series, d: dt.date) -> float:
    wal, tga, rrp = at(S["WALCL"], d), at(S["TGA"], d), at(S["RRPONTSYD"], d)
    if not (wal and tga and rrp):
        raise InsufficientData("net liquidity inputs missing")
    return wal.value - tga.value - rrp.value  # all in billions


def global_liquidity(S: Series) -> FactorResult:
    for sid in ("WALCL", "TGA", "RRPONTSYD"):
        need(S, sid, 5)
    nfci = need(S, "NFCI", 6)
    wal = S["WALCL"]
    d0 = wal[-1].date
    now, then = _net_liquidity(S, d0), _net_liquidity(S, d0 - dt.timedelta(days=28))
    delta = now - then
    if delta >= 100: base = 2
    elif delta >= 30: base = 1
    elif delta <= -100: base = -2
    elif delta <= -30: base = -1
    else: base = 0
    n_chg = change(nfci, 28)
    nfci_adj = -1 if n_chg > 0.03 else 1 if n_chg < -0.03 else 0
    cb_moves, cb_txt = [], []
    for sid, label in (("ECBASSETSW", "ECB assets"), ("JPNASSETS", "BoJ assets")):
        if S.get(sid) and len(S[sid]) >= 2:
            try:
                p = pct(S[sid], 91)
            except InsufficientData:
                continue
            cb_moves.append(p)
            cb_txt.append((f"{label}, 13 weeks", f"{p:+.1f}%"))
    cb_adj = 0
    if len(cb_moves) == 2:
        cb_adj = -1 if all(p < 0 for p in cb_moves) else 1 if all(p > 0 for p in cb_moves) else 0
    score = clamp(base + 0.25 * (nfci_adj + cb_adj))
    tga = S["TGA"][-1]
    return FactorResult(
        "liq", score,
        f"Fed net liquidity (balance sheet minus Treasury account minus reverse repo) changed {delta:+.0f}B over four weeks. Financial conditions are {'tightening' if n_chg > 0.03 else 'easing' if n_chg < -0.03 else 'steady'}.",
        [("Fed total assets", f"${wal[-1].value / 1000:.3f}T"), ("Treasury account (TGA)", f"${tga.value:.0f}B"),
         ("Reverse repo", f"${S['RRPONTSYD'][-1].value:.0f}B"), ("Net liquidity", f"${now / 1000:.3f}T"),
         ("Net liquidity, 4 weeks", f"{delta:+.0f}B"), ("NFCI (negative = loose)", f"{nfci[-1].value:.3f}"),
         ("NFCI, 4 weeks", f"{n_chg:+.3f}")] + cb_txt,
        wal[-1].date, 14,
    )


def fiscal(S: Series) -> FactorResult:
    mts, gdp = need(S, "MTSDS133FMS", 24), need(S, "GDP")
    last12 = sum(o.value for o in mts[-12:])        # millions; negative = deficit
    prev12 = sum(o.value for o in mts[-24:-12])
    deficit_pct = -last12 / (gdp[-1].value * 1000) * 100
    widening = (last12 - prev12) / abs(prev12) * 100 if prev12 else 0.0  # negative = wider deficit
    if deficit_pct >= 6.5: base = 2
    elif deficit_pct >= 5.0: base = 1
    elif deficit_pct >= 3.0: base = 0
    else: base = -1
    adj = 0.5 if widening <= -5 else -0.5 if widening >= 5 else 0
    return FactorResult(
        "fis", clamp(base + adj),
        f"The 12-month federal deficit is {deficit_pct:.1f}% of GDP and {'wider' if widening < 0 else 'narrower'} than a year earlier by {abs(widening):.0f}%.",
        [("Deficit, 12 months", f"${-last12 / 1e6:.2f}T"), ("Deficit / GDP", f"{deficit_pct:.1f}%"),
         ("Vs prior 12 months", f"{-widening:+.0f}% wider" if widening < 0 else f"{widening:.0f}% narrower")],
        mts[-1].date, 75,
    )


def tax_dereg(S: Series, manual: dict) -> FactorResult:
    as_of = dt.date.fromisoformat(manual["updated"])
    readings = [("Analyst score", f"{manual['score']:+d}"), ("Last updated", manual["updated"])]
    loans = S.get("TOTLL")
    if loans and len(loans) > 40:
        readings.append(("Bank loan growth (y/y)", f"{yoy(loans):.1f}%"))
    return FactorResult("tax", manual["score"], manual["note"], readings, as_of, 45, source="manual",
                        notes=["Set by an analyst. Update through PUT /macro/manual/tax."])


def confirmation(S: Series) -> dict:
    """Market confirmation: not a scored factor. Used by the engine's credit check and shown in the UI."""
    out: dict = {"items": [], "credit_widening": None}
    hy = S.get("BAMLH0A0HYM2")
    if hy and len(hy) > 10:
        try:
            w = change(hy, 91)
            out["credit_widening"] = round(w, 2)
            out["items"].append(["High-yield spread", f"{hy[-1].value:.2f}%", f"{w:+.2f} pts in 3 months"])
        except InsufficientData:
            pass
    vix = S.get("VIXCLS")
    if vix:
        out["items"].append(["VIX", f"{vix[-1].value:.1f}", vix[-1].date.isoformat()])
    spx = S.get("SP500")
    if spx and len(spx) > 10:
        try:
            out["items"].append(["S&P 500", f"{spx[-1].value:,.0f}", f"{pct(spx, 30):+.1f}% in 30 days"])
        except InsufficientData:
            pass
    return out
