# CANARY macro live feed

Pulls FRED and U.S. Treasury FiscalData, scores seven macro factors from -2 (tightening) to +2 (easing),
and reports when they align. The dashboard is served at `/macro/`.

## Install

1. `pip install httpx` (FastAPI and Pydantic are already in the API).
2. Copy `canary/macro/` into `apps/api/canary/macro/`, and `tests/test_macro.py` into `apps/api/tests/`.
3. In your FastAPI app:

       from canary.macro import macro_router
       app.include_router(macro_router)

4. Get a free FRED key: https://fred.stlouisfed.org/docs/api/api_key.html
5. Set environment variables on Railway (and locally):

       FRED_API_KEY=...            # required
       MACRO_ADMIN_TOKEN=...       # required for POST /macro/refresh and PUT /macro/manual/tax
       MACRO_REFRESH_MINUTES=360   # optional, default 6 hours
       MACRO_DATA_DIR=/data        # optional; point at a Railway volume so history survives deploys

The first request to `/macro/snapshot` starts a background loop that refreshes on the schedule above.

## Where each factor comes from

| Factor | Source | Rule (see `scoring.py`) |
|---|---|---|
| Monetary policy | FRED `DFEDTARU/L`, `DFF`, `DGS2` | 2-year yield vs fed funds (hike/cut pricing), plus any target change in the last 90 days |
| Economic data | `PCEPILFE`, `CPIAUCSL`, `CPILFESL`, `UNRATE`, `PAYEMS`, `GDPC1` | Core PCE level, moved one notch toward easing if the labour market is weakening |
| Dollar | `DTWEXBGS` (Fed broad dollar index) | 90-day % change |
| Money supply | `M2SL` | Year-over-year growth |
| Global liquidity | `WALCL`, Treasury DTS TGA (FRED `WTREGEN` fallback), `RRPONTSYD`, `NFCI`, `ECBASSETSW`, `JPNASSETS` | 4-week change in Fed net liquidity, nudged by NFCI and ECB/BoJ balance sheets |
| Fiscal | `MTSDS133FMS`, `GDP` | 12-month deficit as % of GDP, nudged by whether it is widening |
| Tax cuts & deregulation | Analyst input (`PUT /macro/manual/tax`) | No clean data series exists. Goes stale after 45 days |

Market confirmation (not scored): high-yield spread `BAMLH0A0HYM2`, `VIXCLS`, `SP500`. A widening spread
adds a sixth check to the trigger list.

## Windows quick start

Double-click `apps/api/run_demo.bat` (synthetic data, no key) or `run_live.bat` (asks for your FRED key). Do not open `static/index.html` directly; the page needs the server running.

## Free hosting: GitHub Actions + GitHub Pages (no server)

GitHub runs `scripts/build_site.py` about every 30 minutes. It pulls FRED and Treasury, scores the seven factors, sends Telegram
alerts, and publishes a static dashboard. Nothing stays running, so there is nothing to pay for. Installable on a phone.

1. Create a **public** GitHub repo and upload this whole folder (the folder that holds `apps/` and `.github/`).
2. Repo Settings, Secrets and variables, Actions, New repository secret. Add `FRED_API_KEY`. Optionally add
   `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID` (see Phone alerts below).
3. Repo Settings, Pages, Source: **GitHub Actions**.
4. Actions tab, "Update CANARY macro dashboard", **Run workflow**. After about a minute your dashboard is at
   `https://<your-username>.github.io/<repo-name>/`.
5. Open that link on your phone and install it (Android Chrome: Install app. iPhone Safari: Share, Add to Home Screen).

Updating the tax cuts and deregulation score: edit `apps/api/data/macro_manual.json` on github.com (pencil icon),
change `score`, `note` and `updated`, and commit. The dashboard rebuilds on its own.

Limits: the page is public, so anyone with the link can see it (your keys are not, they stay in Secrets).
Data is as fresh as the last run, about 30 minutes old, and you can press Run workflow for an instant refresh.
GitHub can pause scheduled runs on a repo with no activity for a long time; if the dashboard stops updating,
open the Actions tab and re-enable the workflow. Edit the `cron` line in `.github/workflows/macro.yml` to change the schedule.

## Run it on your phone with a server (Railway, paid)

1. Put the `apps/api` folder in a GitHub repo (private is fine). Do not commit your FRED key or a `data/` folder.
2. On railway.com: New Project, Deploy from GitHub repo, set the service's root directory to `apps/api`. `railway.json` and `main.py` already say how to start it.
3. Variables tab: `FRED_API_KEY`, `MACRO_ADMIN_TOKEN` (any long random string), `MACRO_DATA_DIR=/data`.
4. Add a Volume mounted at `/data` so score history survives redeploys.
5. Settings, Networking, Generate Domain. Open `https://<your-domain>/macro/` on your phone.
6. Install it: on Android Chrome use the menu, Install app. On iPhone use Safari, Share, Add to Home Screen.

The data is public macro series, so the dashboard has no login. Anyone with the link can view it. The refresh and tax-score endpoints need your admin token.

## Phone alerts (Telegram)

Sends a message when a factor changes direction, the regime changes, or the big-move trigger changes.
The first run only records a baseline. A factor is not alerted again for 12 hours. Stale data never alerts.

1. In Telegram, message **@BotFather**, send `/newbot`, follow the prompts, and copy the token.
2. Open a chat with your new bot and send it any message.
3. Open `https://api.telegram.org/bot<TOKEN>/getUpdates` in a browser and copy the number after `"chat":{"id":`.
4. On Railway, add `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`, and optionally `MACRO_PUBLIC_URL` (your dashboard link).
5. Test it: `curl -X POST https://<your-domain>/macro/alerts/test -H "X-Admin-Token: <your token>"`

To try it locally, set the same variables before `run_live.bat`. Keep the bot token private.

## Try it without a key

    cd apps/api
    MACRO_DEMO=1 uvicorn macro_dev:app --port 8000     # http://localhost:8000/macro/

Demo mode uses synthetic data and says so on the page.

## Update the analyst score

    curl -X PUT $HOST/macro/manual/tax -H "X-Admin-Token: $MACRO_ADMIN_TOKEN" \
      -H "Content-Type: application/json" -d '{"score": 2, "note": "Basel III final rule published"}'

## Tests

    pytest        # 32 offline tests; FRED and Treasury are mocked

## Verify on first live run

The tests prove the logic against mocked responses shaped like the documented FRED and FiscalData APIs.
They could not call the real services from where this was built. On your first live run, open
`/macro/snapshot` and check `status.errors` and each factor's readings against FRED. The likeliest
surprises are the Treasury DTS field names for the TGA balance (the code falls back to FRED `WTREGEN`)
and `JPNASSETS` availability (optional; dropping it only removes one small adjustment).
