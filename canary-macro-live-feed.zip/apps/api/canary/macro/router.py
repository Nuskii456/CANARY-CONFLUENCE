"""FastAPI router. Mount with:  app.include_router(macro_router)

Endpoints (all under /macro):
  GET  /               the live dashboard page
  GET  /snapshot       latest factors, scores, regime, playbook
  POST /analyze        what-if: {"scores": {"mon": -2, ...}} -> analysis
  GET  /history        daily net score and regime
  POST /refresh        force a refresh (needs X-Admin-Token)
  PUT  /manual/tax     set the analyst score for tax cuts & deregulation (needs X-Admin-Token)
"""
from __future__ import annotations

import hmac
import os
from pathlib import Path

from fastapi import APIRouter, Header, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from . import engine
from .service import MacroService

router = APIRouter(prefix="/macro", tags=["macro"])
_service: MacroService | None = None
STATIC = Path(__file__).parent / "static"


def get_service() -> MacroService:
    global _service
    if _service is None:
        _service = MacroService()
    return _service


def set_service(svc: MacroService | None) -> None:
    """Used by tests and by apps that want to build the service themselves."""
    global _service
    _service = svc


def _require_admin(token: str | None) -> None:
    expected = os.environ.get("MACRO_ADMIN_TOKEN", "")
    if not expected:
        raise HTTPException(503, "MACRO_ADMIN_TOKEN is not set on the server")
    if not token or not hmac.compare_digest(token, expected):
        raise HTTPException(401, "invalid admin token")


class AnalyzeIn(BaseModel):
    scores: dict[str, int]


class ManualIn(BaseModel):
    score: int = Field(ge=-2, le=2)
    note: str = Field(min_length=3, max_length=500)


@router.get("", include_in_schema=False)
@router.get("/", include_in_schema=False)
async def page():
    return FileResponse(STATIC / "index.html")


@router.get("/snapshot")
async def snapshot():
    svc = get_service()
    await svc.ensure_started()
    return svc.snapshot()


@router.post("/analyze")
async def analyze(body: AnalyzeIn):
    svc = get_service()
    await svc.ensure_started()
    snap = svc.snapshot() or {}
    try:
        return engine.analyze(body.scores, snap.get("credit_widening"))
    except ValueError as exc:
        raise HTTPException(422, str(exc))


@router.get("/history")
async def history(limit: int = 180):
    return get_service().history(max(1, min(limit, 1000)))


@router.post("/refresh")
async def refresh(x_admin_token: str | None = Header(default=None)):
    _require_admin(x_admin_token)
    return await get_service().refresh()


@router.put("/manual/tax")
async def set_manual(body: ManualIn, x_admin_token: str | None = Header(default=None)):
    _require_admin(x_admin_token)
    svc = get_service()
    saved = svc.manual.set("tax", body.score, body.note)
    await svc.refresh()
    return saved


@router.post("/alerts/test")
async def alerts_test(x_admin_token: str | None = Header(default=None)):
    _require_admin(x_admin_token)
    a = get_service().alerts
    if not a.configured:
        raise HTTPException(503, "Set TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID on the server")
    ok = await a.send("CANARY test alert: Telegram is connected.")
    return {"sent": ok}


# Registered last so it never shadows the API routes above.
_ASSETS = {
    "manifest.webmanifest": "application/manifest+json",
    "sw.js": "application/javascript",
    "icon.svg": "image/svg+xml",
    "icon-192.png": "image/png",
    "icon-512.png": "image/png",
    "apple-touch-icon.png": "image/png",
}


@router.get("/{name}", include_in_schema=False)
async def asset(name: str):
    """App-install files (manifest, service worker, icons). Only this fixed list is served."""
    if name not in _ASSETS:
        raise HTTPException(404, "not found")
    headers = {"Cache-Control": "no-cache"} if name == "sw.js" else None
    return FileResponse(STATIC / name, media_type=_ASSETS[name], headers=headers)
