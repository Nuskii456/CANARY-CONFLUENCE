// Offline support: the page shell is cached, and the last good data is shown when there is no connection.
// Paths are relative to the worker's own scope, so this works at /macro/ and at /<repo-name>/.
const SHELL = 'canary-shell-v2';
const SCOPE = new URL(self.registration.scope);
const FILES = ['./', 'manifest.webmanifest', 'icon-192.png'].map(f => new URL(f, SCOPE).href);
self.addEventListener('install', e => { e.waitUntil(caches.open(SHELL).then(c => c.addAll(FILES))); self.skipWaiting(); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== SHELL).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== SCOPE.origin || !url.pathname.startsWith(SCOPE.pathname)) return;
  // Network first, so data is always fresh; fall back to the last copy when offline.
  e.respondWith(fetch(req).then(res => {
    if (res.ok) { const copy = res.clone(); caches.open(SHELL).then(c => c.put(req, copy)); }
    return res;
  }).catch(() => caches.match(req).then(r => r || caches.match(SCOPE.href))));
});
