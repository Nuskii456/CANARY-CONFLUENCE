"""Analyst-set input for the one factor that has no clean data series: tax cuts & deregulation.

Stored as a small JSON file. The score goes stale after MAX_AGE_DAYS so an old opinion is never
presented as current without a warning.
"""
from __future__ import annotations

import datetime as dt
import json
import os
import tempfile
from pathlib import Path

MAX_AGE_DAYS = 45

DEFAULT = {
    "tax": {
        "score": 1,
        "note": "Larger 2026 refunds and eased bank capital rules (eSLR final, Basel III re-proposal) support credit. No new tax cuts have passed and Congress is now split.",
        "updated": "2026-11-07",
    }
}


class ManualStore:
    def __init__(self, path: Path):
        self.path = path

    def _load(self) -> dict:
        try:
            return json.loads(self.path.read_text())
        except (OSError, ValueError):
            return json.loads(json.dumps(DEFAULT))

    def get(self, fid: str) -> dict:
        data = self._load()
        return data.get(fid) or DEFAULT[fid]

    def set(self, fid: str, score: int, note: str) -> dict:
        if fid not in DEFAULT:
            raise ValueError("unknown manual factor")
        if isinstance(score, bool) or not isinstance(score, int) or not -2 <= score <= 2:
            raise ValueError("score must be an integer from -2 to 2")
        data = self._load()
        data[fid] = {"score": score, "note": note.strip()[:500], "updated": dt.date.today().isoformat()}
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=self.path.parent)
        with os.fdopen(fd, "w") as fh:
            json.dump(data, fh, indent=2)
        os.replace(tmp, self.path)  # atomic
        return data[fid]
