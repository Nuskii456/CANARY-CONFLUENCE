"""Fetches all series, scores the factors, keeps the latest snapshot in memory and a daily history on disk."""
from __future__ import annotations

import asyncio
import datetime as dt
import json
import logging
import os
from pathlib import Path

import httpx

from . import engine, scoring
from .manual import ManualStore
from .alerts import Alerts
from .providers import MARKETS, FredClient, ProviderError, Obs, scale_to_billions, tga_closing_balance, yahoo_quote

log = logging.getLogger("canary.macro")

SERIES = [
    "DFEDTARU", "DFEDTARL", "DFF", "DGS2", "PCEPILFE", "CPIAUCSL", "CPILFESL", "UNRATE", "PAYEMS", "GDPC1",
    "DTWEXBGS", "M2SL", "WALCL", "WTREGEN", "RRPONTSYD", "NFCI", "ECBASSETSW", "JPNASSETS",
    "MTSDS133FMS", "GDP", "TOTLL", "VIXCLS", "BAMLH0A0HYM2", "SP500",
]
LOOKBACK = {"MTSDS133FMS": 1100, "GDP": 1100, "PAYEMS": 1100, "UNRATE": 1100, "SP500": 200, "VIXCLS": 200}
MONEY_SERIES = ("WALCL", "WTREGEN", "RRPONTSYD")  # normalised to billions using FRED's units string

FRESHNESS = [  # series, label, how often it is published
    ("DGS2", "2-year Treasury yield", "daily, 1 business day lag"), ("DFF", "Effective fed funds rate", "daily"),
    ("TGA", "Treasury cash balance (TGA)", "daily"), ("BAMLH0A0HYM2", "High-yield spread", "daily, 1 day lag"),
    ("WALCL", "Fed balance sheet", "weekly, Thursday"), ("NFCI", "Financial conditions (NFCI)", "weekly, Wednesday"),
    ("PAYEMS", "Nonfarm payrolls (000s)", "monthly, first Friday"), ("UNRATE", "Unemployment rate (%)", "monthly, first Friday"),
    ("CPIAUCSL", "CPI index", "monthly, mid-month"), ("CPILFESL", "Core CPI index", "monthly, mid-month"),
    ("PCEPILFE", "Core PCE index", "monthly, end of month"), ("M2SL", "M2 money supply", "monthly, about 3 weeks after month end"),
    ("MTSDS133FMS", "Federal budget balance", "monthly, 8th business day"), ("GDPC1", "Real GDP", "quarterly"),
]

FACTOR_META = {
    "mon": {"flip": "Rate-cut pricing returning (2-year yield falling below fed funds) moves this toward Ease. A hike, or the 2-year yield 0.5 pts above fed funds, moves it to Tight++.",
            "src": [["Fed funds target", "https://fred.stlouisfed.org/series/DFEDTARU"], ["2-year yield", "https://fred.stlouisfed.org/series/DGS2"]]},
    "dat": {"flip": "Core PCE under 2.5% or a rising unemployment gap moves this toward Ease. Core PCE above 3.25% moves it to Tight++.",
            "src": [["Core PCE", "https://fred.stlouisfed.org/series/PCEPILFE"], ["Payrolls", "https://fred.stlouisfed.org/series/PAYEMS"], ["Unemployment", "https://fred.stlouisfed.org/series/UNRATE"]]},
    "dxy": {"flip": "A 90-day fall of more than 0.75% in the dollar moves this toward Ease. A rise above 2% moves it to Tight++.",
            "src": [["ICE DXY (Yahoo Finance)", "https://finance.yahoo.com/quote/DX-Y.NYB/"], ["Fed broad dollar index (fallback)", "https://fred.stlouisfed.org/series/DTWEXBGS"]]},
    "m2": {"flip": "M2 growth above 6.5% moves this to Ease. Growth under 2.5% moves it to Tight.",
           "src": [["M2", "https://fred.stlouisfed.org/series/M2SL"]]},
    "liq": {"flip": "Net liquidity rising by 30B or more over four weeks, with NFCI falling, moves this to Ease. A fall of 100B moves it to Tight++.",
            "src": [["Fed balance sheet", "https://fred.stlouisfed.org/series/WALCL"], ["Treasury account", "https://fiscaldata.treasury.gov/datasets/daily-treasury-statement/operating-cash-balance"], ["NFCI", "https://fred.stlouisfed.org/series/NFCI"]]},
    "fis": {"flip": "A deficit under 5% of GDP moves this to Neutral. Over 6.5% moves it to Ease++.",
            "src": [["Monthly deficit", "https://fred.stlouisfed.org/series/MTSDS133FMS"], ["GDP", "https://fred.stlouisfed.org/series/GDP"]]},
    "tax": {"flip": "A final Basel capital rule or new tax relief moves this toward Ease. Gridlock or reversal moves it toward Neutral.",
            "src": [["Bank loans", "https://fred.stlouisfed.org/series/TOTLL"]]},
}


def _data_dir() -> Path:
    return Path(os.environ.get("MACRO_DATA_DIR", "./data"))


class MacroService:
    def __init__(self, http: httpx.AsyncClient | None = None, api_key: str | None = None,
                 data_dir: Path | None = None, refresh_minutes: int | None = None, demo: bool = False):
        self.demo = demo
        self._http = http or httpx.AsyncClient()
        self._api_key = api_key if api_key is not None else os.environ.get("FRED_API_KEY", "")
        self.dir = data_dir or _data_dir()
        self.manual = ManualStore(self.dir / "macro_manual.json")
        self.history_path = self.dir / "macro_history.jsonl"
        self.every = (refresh_minutes or int(os.environ.get("MACRO_REFRESH_MINUTES", "30"))) * 60
        self._snapshot: dict | None = None
        self._last_good: dict[str, dict] = {}
        self._markets: list[dict] = []
        self.alerts = Alerts(self.dir, self._http)
        self._lock = asyncio.Lock()
        self._task: asyncio.Task | None = None

    # ---- lifecycle ---------------------------------------------------------------------------
    async def ensure_started(self) -> None:
        if self._task is None or self._task.done():
            self._task = asyncio.create_task(self._loop())
        if self._snapshot is None:
            await self.refresh()

    async def _loop(self) -> None:
        while True:
            await asyncio.sleep(self.every)
            try:
                await self.refresh()
            except Exception:  # keep the loop alive whatever happens
                log.exception("macro refresh failed")

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
        await self._http.aclose()

    def snapshot(self) -> dict | None:
        return self._snapshot

    # ---- fetch -------------------------------------------------------------------------------
    async def _fetch_all(self) -> tuple[scoring.Series, dict[str, str]]:
        fred = FredClient(self._api_key, self._http)
        errors: dict[str, str] = {}

        async def one(sid: str):
            return sid, await fred.observations(sid, LOOKBACK.get(sid, 900))

        async def units(sid: str):
            return sid, await fred.units(sid)

        results = await asyncio.gather(
            *[one(s) for s in SERIES], *[units(s) for s in MONEY_SERIES], tga_closing_balance(self._http),
            return_exceptions=True,
        )
        S: scoring.Series = {}
        unit_of: dict[str, str] = {}
        # results order: one tuple per SERIES, then one units tuple per MONEY_SERIES, then the TGA list
        labels = SERIES + [f"{s} units" for s in MONEY_SERIES] + ["TGA"]
        for label, r in zip(labels, results):
            if isinstance(r, Exception):
                errors[label] = str(r) if isinstance(r, ProviderError) else type(r).__name__
        n = len(SERIES)
        for i, sid in enumerate(SERIES):
            r = results[i]
            if not isinstance(r, Exception):
                S[sid] = r[1]
        for j, sid in enumerate(MONEY_SERIES):
            r = results[n + j]
            if not isinstance(r, Exception):
                unit_of[sid] = r[1]
        for sid in MONEY_SERIES:
            if sid in S:
                if sid in unit_of:
                    k = scale_to_billions(unit_of[sid])
                    S[sid] = [Obs(o.date, o.value * k) for o in S[sid]]
                else:
                    errors[sid] = errors.get(sid, "units unavailable")
                    del S[sid]
        tga = results[-1]
        if not isinstance(tga, Exception):
            S["TGA"] = tga
        elif "WTREGEN" in S:  # fall back to the weekly FRED series
            S["TGA"] = S["WTREGEN"]
            errors["TGA"] = f"{tga}; used FRED WTREGEN instead"
        await self._fetch_markets(S, errors)
        return S, errors

    async def _fetch_markets(self, S: scoring.Series, errors: dict[str, str]) -> None:
        """Live prices from Yahoo Finance. FRED lags by a day or more, so the tape and the dollar factor use these."""
        results = await asyncio.gather(*[yahoo_quote(self._http, sym) for sym, _, _ in MARKETS], return_exceptions=True)
        markets = []
        for (sym, label, dec), r in zip(MARKETS, results):
            if isinstance(r, Exception):
                errors[f"Yahoo {sym}"] = str(r) if isinstance(r, ProviderError) else type(r).__name__
                continue
            markets.append({"symbol": sym, "label": label, "decimals": dec, "price": r.price,
                            "change_pct": (r.price / r.prev_close - 1) * 100 if r.prev_close else 0.0,
                            "time": r.time.isoformat(timespec="seconds")})
            if sym == "DX-Y.NYB":
                S["DXY_LIVE"] = r.closes
        if markets or not self._markets:  # on a total failure keep the last tape; the page shows its age
            self._markets = markets

    def _freshness(self, S: scoring.Series, today: dt.date) -> list[dict]:
        out = []
        for sid, label, cadence in FRESHNESS:
            obs = S.get(sid)
            if not obs:
                continue
            last = obs[-1]
            prev = obs[-2].value if len(obs) > 1 else None
            out.append({"series": sid, "label": label, "cadence": cadence, "value": last.value,
                        "previous": prev, "period": last.date.isoformat(), "age_days": (today - last.date).days})
        return out

    # ---- refresh -----------------------------------------------------------------------------
    async def refresh(self) -> dict:
        async with self._lock:
            today = dt.date.today()
            try:
                S, errors = await self._fetch_all()
            except ProviderError as exc:  # e.g. missing API key
                S, errors = {}, {"setup": str(exc)}
            manual = self.manual.get("tax")
            computers = {
                "mon": lambda: scoring.monetary(S), "dat": lambda: scoring.economic_data(S),
                "dxy": lambda: scoring.dollar(S), "m2": lambda: scoring.money_supply(S),
                "liq": lambda: scoring.global_liquidity(S), "fis": lambda: scoring.fiscal(S),
                "tax": lambda: scoring.tax_dereg(S, manual),
            }
            factors = []
            for f in engine.FACTORS:
                fid = f["id"]
                try:
                    d = computers[fid]().to_dict(today)
                    self._last_good[fid] = d
                except Exception as exc:  # one bad series must not take down the others
                    errors[fid] = errors.get(fid) or f"{type(exc).__name__}: {exc}"
                    prev = self._last_good.get(fid)
                    if prev:
                        d = {**prev, "stale": True, "confidence": "Low",
                             "notes": prev.get("notes", []) + ["Using the last good reading; this refresh failed."]}
                    else:
                        d = {"id": fid, "score": 0, "headline": "No data yet for this factor.", "readings": [],
                             "as_of": None, "age_days": None, "stale": True, "confidence": "None", "source": "none",
                             "notes": [errors[fid]]}
                factors.append({**f, **d, **FACTOR_META[fid]})
            conf = scoring.confirmation(S)
            if self._markets:  # the live tape replaces the lagging FRED VIX and S&P 500 entries
                conf["items"] = [i for i in conf["items"] if i[0] not in ("VIX", "S&P 500")]
            scores = {f["id"]: f["score"] for f in factors}
            analysis = engine.analyze(scores, conf["credit_widening"])
            scenarios = [{"k": "live", "n": "Live", "scores": scores}] + engine.SCENARIOS
            self._snapshot = {
                "generated_at": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
                "factors": factors, "analysis": analysis, "confirmation": conf["items"],
                "credit_widening": conf["credit_widening"], "scenarios": scenarios,
                "markets": list(self._markets), "freshness": self._freshness(S, today),
                "status": {"demo": self.demo, "ok": not errors, "errors": errors, "live_factors": sum(f["source"] == "live" and not f["stale"] for f in factors)},
            }
            if len(errors) < len(SERIES) // 2:
                self._append_history(today, analysis, scores)
                if not self.demo:
                    try:
                        await self.alerts.check(self._snapshot)
                    except Exception:  # an alert problem must never break a refresh
                        log.exception("macro alert check failed")
            return self._snapshot

    # ---- history -----------------------------------------------------------------------------
    def _append_history(self, day: dt.date, analysis: dict, scores: dict) -> None:
        rows = self.history(10_000)
        row = {"date": day.isoformat(), "net": analysis["net"], "regime": analysis["regime_key"], "scores": scores}
        rows = [r for r in rows if r["date"] != row["date"]] + [row]
        try:
            self.history_path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.history_path.with_suffix(".tmp")
            tmp.write_text("\n".join(json.dumps(r) for r in rows[-1000:]) + "\n")
            os.replace(tmp, self.history_path)
        except OSError:
            log.exception("could not write macro history")

    def history(self, limit: int = 180) -> list[dict]:
        try:
            lines = self.history_path.read_text().splitlines()
        except OSError:
            return []
        out = []
        for ln in lines:
            try:
                out.append(json.loads(ln))
            except ValueError:
                continue
        return out[-limit:]
