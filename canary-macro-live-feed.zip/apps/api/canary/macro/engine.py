"""Confluence engine: turns seven factor scores (-2..+2) into a regime, risk budget and trigger.

This is the single place the alignment logic lives. The dashboard calls it through the API
for both live data and what-if scenarios.
"""
from __future__ import annotations

FACTORS = [
    # id, name, short label, weight, is_plumbing
    {"id": "mon", "name": "Monetary policy", "short": "Policy", "w": 22, "core": True},
    {"id": "dat", "name": "Economic data", "short": "Data", "w": 12, "core": False},
    {"id": "dxy", "name": "US dollar (DXY)", "short": "Dollar", "w": 14, "core": True},
    {"id": "m2", "name": "Money supply", "short": "M2", "w": 14, "core": True},
    {"id": "liq", "name": "Global liquidity", "short": "Liquidity", "w": 18, "core": True},
    {"id": "fis", "name": "Fiscal policy", "short": "Fiscal", "w": 12, "core": False},
    {"id": "tax", "name": "Tax cuts & deregulation", "short": "Tax/Dereg", "w": 8, "core": False},
]
IDS = [f["id"] for f in FACTORS]
assert sum(f["w"] for f in FACTORS) == 100

SCENARIOS = [
    {"k": "easing", "n": "Easing confluence", "scores": {"mon": 2, "dat": 1, "dxy": 2, "m2": 2, "liq": 2, "fis": 1, "tax": 1}},
    {"k": "tightening", "n": "Tightening confluence", "scores": {"mon": -2, "dat": -2, "dxy": -2, "m2": -1, "liq": -2, "fis": -1, "tax": 0}},
    {"k": "pivot", "n": "Fed pivot", "scores": {"mon": 1, "dat": -1, "dxy": 0, "m2": 0, "liq": -1, "fis": 1, "tax": 1}},
]

_ow, _uw, _nt = "ow", "uw", "nt"
PLAYBOOK = {
    "strongEase": {"tag": "Strong easing confluence", "title": "Easing window", "lo": 80, "hi": 100,
        "lede": "Policy, dollar, money and liquidity are all loosening together. This is when large trends tend to start and persist.",
        "do": ["Build core risk positions in stages and add on pullbacks.", "Favour high-beta assets that respond to liquidity: growth equities, small caps, crypto.", "Let winners run; widen stops to avoid shakeouts."],
        "avoid": ["Fading the move because it looks stretched.", "Holding large cash while the factors stay aligned."],
        "lean": {"Equities": [_ow, "Overweight"], "Credit": [_ow, "Overweight"], "Dollar": [_uw, "Underweight"], "Gold": [_ow, "Overweight"], "Crypto": [_ow, "Overweight"], "Duration": [_ow, "Overweight"]}},
    "tiltEase": {"tag": "Easing tilt", "title": "Constructive", "lo": 55, "hi": 75,
        "lede": "Most factors point toward easing, but not all of them. Participate with discipline and wait for the stragglers.",
        "do": ["Hold a solid risk core and add only when another factor flips to easing.", "Prefer liquid, quality risk assets.", "Keep a defined exit if the dollar or policy reverses."],
        "avoid": ["Max size before the plumbing factors confirm.", "Ignoring the one or two factors still leaning tight."],
        "lean": {"Equities": [_ow, "Overweight"], "Credit": [_ow, "Overweight"], "Dollar": [_nt, "Neutral"], "Gold": [_nt, "Neutral"], "Crypto": [_ow, "Overweight"], "Duration": [_nt, "Neutral"]}},
    "mixed": {"tag": "Split market", "title": "Stay selective", "lo": 25, "hi": 45,
        "lede": "Factors disagree, so the net signal is weak. Moves tend to be choppy and reverse.",
        "do": ["Trade smaller and take profits sooner.", "Wait for two or more factors to flip in the same direction.", "Use range tactics; avoid chasing breakouts."],
        "avoid": ["Large directional bets.", "Treating one strong headline as a regime change."],
        "lean": {k: [_nt, "Neutral"] for k in ["Equities", "Credit", "Dollar", "Gold", "Crypto", "Duration"]}},
    "tiltTight": {"tag": "Tightening tilt", "title": "Conservative", "lo": 20, "hi": 40,
        "lede": "Most factors point toward tighter conditions. Rallies are more likely to fail, and drawdowns are likelier to run than to snap back.",
        "do": ["Hold cash and short-dated bills; keep dry powder for the next flip.", "Hedge existing risk; prefer quality balance sheets.", "Take shorts or hedges only on confirmed breakdowns, and keep them small until more factors align."],
        "avoid": ["Buying dips in high-beta assets before the dollar or policy turns.", "Large leverage on any direction."],
        "lean": {"Equities": [_uw, "Underweight"], "Credit": [_uw, "Underweight"], "Dollar": [_ow, "Overweight"], "Gold": [_nt, "Neutral"], "Crypto": [_uw, "Underweight"], "Duration": [_nt, "Neutral"]}},
    "strongTight": {"tag": "Strong tightening confluence", "title": "Defensive window", "lo": 0, "hi": 25,
        "lede": "Policy, dollar, money and liquidity are all tightening. Large downside moves are most likely here.",
        "do": ["Cut gross exposure and raise cash.", "Size downside trades or hedges to the move, not to the hope.", "Wait for the first plumbing factor to turn before rebuilding longs."],
        "avoid": ["Catching falling knives.", "Carrying leveraged risk through major policy dates."],
        "lean": {"Equities": [_uw, "Underweight"], "Credit": [_uw, "Underweight"], "Dollar": [_ow, "Overweight"], "Gold": [_nt, "Neutral"], "Crypto": [_uw, "Underweight"], "Duration": [_ow, "Overweight"]}},
}


def validate_scores(scores: dict) -> dict[str, int]:
    out = {}
    for fid in IDS:
        if fid not in scores:
            raise ValueError(f"missing score for {fid}")
        v = scores[fid]
        if isinstance(v, bool) or not isinstance(v, int) or not -2 <= v <= 2:
            raise ValueError(f"score for {fid} must be an integer from -2 to 2")
        out[fid] = v
    extra = set(scores) - set(IDS)
    if extra:
        raise ValueError(f"unknown factors: {sorted(extra)}")
    return out


def analyze(scores: dict, credit_widening: float | None = None) -> dict:
    """credit_widening: change in high-yield spread (percentage points) over ~3 months, if known."""
    s = validate_scores(scores)
    net = core_n = imp_n = 0.0
    core_w = imp_w = 0
    eas = tig = neu = core_eas = core_tig = 0
    for f in FACTORS:
        v = s[f["id"]]
        c = f["w"] * v / 2
        net += c
        eas += v > 0
        tig += v < 0
        neu += v == 0
        if f["core"]:
            core_n += c
            core_w += f["w"]
            core_eas += v > 0
            core_tig += v < 0
        else:
            imp_n += c
            imp_w += f["w"]
    direction = "ease" if net > 0 else "tight" if net < 0 else "mixed"
    same = eas if direction == "ease" else tig if direction == "tight" else max(eas, tig)
    core_same = core_eas if direction == "ease" else core_tig if direction == "tight" else 0

    key = "mixed"
    if direction != "mixed":
        if abs(net) >= 55 and same >= 5 and core_same >= 3:
            key = "strongEase" if direction == "ease" else "strongTight"
        elif abs(net) >= 20 and same >= 4:
            key = "tiltEase" if direction == "ease" else "tiltTight"
    pb = PLAYBOOK[key]

    want = 1 if direction == "ease" else -1 if direction == "tight" else 0
    heavy_opposes = want != 0 and any(s[f["id"]] * want < 0 for f in FACTORS if f["w"] >= 18)
    checks = [
        {"ok": direction != "mixed" and same >= 5, "text": f"5 or more of 7 factors lean the same way ({same} now)."},
        {"ok": direction != "mixed" and core_same == 4, "text": f"All four plumbing factors agree: policy, dollar, M2, global liquidity ({core_same} of 4)."},
        {"ok": abs(net) >= 55, "text": f"Net score is beyond ±55 ({net:+.0f} now)."},
        {"ok": want != 0 and s["dxy"] * want > 0, "text": "The dollar confirms: weakening for easing, strengthening for tightening."},
        {"ok": want != 0 and not heavy_opposes, "text": "Neither policy nor global liquidity (the two heaviest) points against the move."},
    ]
    if credit_widening is not None:
        ok = (direction == "ease" and credit_widening <= 0.25) or (direction == "tight" and credit_widening >= -0.25)
        checks.append({"ok": ok, "text": f"High-yield credit spreads confirm ({credit_widening:+.2f} pts over 3 months)."})
    passed = sum(c["ok"] for c in checks)
    total = len(checks)
    strong = key in ("strongEase", "strongTight")
    if strong and passed >= total - 1:
        trig = "go"
    elif passed >= round(0.6 * total):
        trig = "arm"
    else:
        trig = "wait"

    plumbing = core_n * 100 / core_w
    impulse = imp_n * 100 / imp_w
    return {
        "net": round(net, 1), "easing": eas, "tightening": tig, "neutral": neu,
        "direction": direction, "same": same, "core_same": core_same,
        "regime_key": key, "playbook": pb,
        "exposure": {"lo": pb["lo"], "hi": pb["hi"]},
        "plumbing": round(plumbing, 1), "impulse": round(impulse, 1),
        "divergence": plumbing * impulse < 0 and abs(plumbing) >= 25 and abs(impulse) >= 10,
        "checklist": checks, "passed": passed, "total": total,
        "trigger": trig,
    }
