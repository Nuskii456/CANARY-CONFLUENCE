"""Production entry point (Railway, or any host).  uvicorn main:app --host 0.0.0.0 --port $PORT

Later, to fold this into the main CANARY API, copy the two macro lines below into its app.
"""
from fastapi import FastAPI
from fastapi.responses import RedirectResponse

from canary.macro import macro_router

app = FastAPI(title="CANARY", docs_url=None, redoc_url=None)
app.include_router(macro_router)


@app.get("/health", include_in_schema=False)
async def health():
    return {"ok": True}


@app.get("/", include_in_schema=False)
async def home():
    return RedirectResponse("/macro/")
