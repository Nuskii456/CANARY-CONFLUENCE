@echo off
rem Starts the CANARY macro dashboard in demo mode (synthetic data, no API key needed).
rem For live data: set FRED_API_KEY=your_key and remove the MACRO_DEMO line below.
cd /d "%~dp0"
set "PY="
py --version >nul 2>nul && set "PY=py"
if not defined PY python --version >nul 2>nul && set "PY=python"
if not defined PY (
  echo.
  echo Python is not installed on this computer.
  echo 1. Go to https://www.python.org/downloads/ and install Python 3.12 or newer.
  echo 2. On the first installer screen, tick "Add python.exe to PATH".
  echo 3. Close this window, then double-click this file again.
  echo.
  pause
  exit /b 1
)
if not exist .venv ( %PY% -m venv .venv )
call .venv\Scripts\activate.bat
python -m pip install -q -r requirements.txt
set MACRO_DEMO=1
set MACRO_DATA_DIR=%~dp0data
start "" http://localhost:8000/macro/
python -m uvicorn macro_dev:app --port 8000
pause
