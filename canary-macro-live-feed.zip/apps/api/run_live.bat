@echo off
rem Starts the dashboard with LIVE FRED + Treasury data. Put your free FRED key below.
cd /d "%~dp0"
if "%FRED_API_KEY%"=="" set /p FRED_API_KEY=Paste your FRED API key: 
set "FRED_API_KEY=%FRED_API_KEY: =%"
echo Using a key with %FRED_API_KEY:~0,4%... (first 4 characters shown)
set "PY="
py --version >nul 2>nul && set "PY=py"
if not defined PY python --version >nul 2>nul && set "PY=python"
if not defined PY (
  echo.
  echo Python is not installed on this computer.
  echo 1. Go to https://www.python.org/downloads/ and install Python 3.12 or newer.
  echo 2. On the first installer screen, tick "Add python.exe to PATH".
  echo 3. Close this window, then double-click this file again.
  echo.
  pause
  exit /b 1
)
if not exist .venv ( %PY% -m venv .venv )
call .venv\Scripts\activate.bat
python -m pip install -q -r requirements.txt
set MACRO_DATA_DIR=%~dp0data
start "" http://localhost:8000/macro/
python -m uvicorn macro_dev:app --port 8000
pause
