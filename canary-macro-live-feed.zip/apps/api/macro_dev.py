"""Run the macro service on its own:  uvicorn macro_dev:app --reload --port 8000  ->  http://localhost:8000/macro/

With FRED_API_KEY set it uses live FRED and Treasury data.
With MACRO_DEMO=1 it serves synthetic data so you can preview the page without a key.
"""
import os

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from canary.macro import macro_router, set_service
from canary.macro.service import MacroService

app = FastAPI(title="CANARY macro")
# Dev only: lets the page work even if it is opened as a file. Remove or restrict in production.
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["GET"], allow_headers=["*"])
if os.environ.get("MACRO_DEMO") == "1":
    from tests.test_macro import mock_http  # synthetic FRED/Treasury responses
    set_service(MacroService(http=mock_http(), api_key="d" * 32, demo=True))
app.include_router(macro_router)


if __name__ == "__main__":  # lets `python macro_dev.py` start the server too
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
