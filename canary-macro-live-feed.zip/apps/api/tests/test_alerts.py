import asyncio
import datetime as dt

import httpx

from canary.macro.alerts import Alerts

T0 = dt.datetime(2026, 11, 9, 12, 0, tzinfo=dt.timezone.utc)
NAMES = {"mon": "Monetary policy", "dxy": "US dollar (DXY)", "liq": "Global liquidity"}


def snap(scores, tag="Tightening tilt", trigger="wait", net=-34, stale=(), source="live"):
    return {
        "analysis": {"playbook": {"tag": tag}, "trigger": trigger, "net": net},
        "factors": [{"id": k, "name": NAMES[k], "score": v, "source": source, "stale": k in stale}
                    for k, v in scores.items()],
    }


class Clock:
    def __init__(self):
        self.t = T0

    def __call__(self):
        return self.t


class FakeHttp:
    def __init__(self, status=200):
        self.posts, self.status = [], status

    async def post(self, url, json=None, timeout=None):
        self.posts.append((url, json))
        return httpx.Response(self.status)


def make(tmp_path, clock=None, http=None, token="123:abc", chat="42"):
    return Alerts(tmp_path, http or FakeHttp(), token=token, chat_id=chat, now=clock or Clock())


def test_first_run_is_silent_baseline(tmp_path):
    a = make(tmp_path)
    assert a.changes(snap({"mon": -2, "dxy": -1})) == []


def test_direction_change_alerts(tmp_path):
    a = make(tmp_path)
    a.changes(snap({"mon": -2, "dxy": -1}))
    lines = a.changes(snap({"mon": -2, "dxy": 1}, tag="Split market", net=-5))
    assert "US dollar (DXY): Lean tight to Lean ease" in lines
    assert any(l.startswith("Regime: Tightening tilt to Split market") for l in lines)


def test_same_direction_move_is_quiet_but_big_move_alerts(tmp_path):
    a = make(tmp_path)
    a.changes(snap({"mon": -1}))
    assert a.changes(snap({"mon": -2})) == []          # still tightening, one notch
    assert a.changes(snap({"mon": 0})) == ["Monetary policy: Tight++ to Flat"]


def test_cooldown_blocks_repeat_then_allows(tmp_path):
    clock = Clock()
    a = make(tmp_path, clock)
    a.changes(snap({"dxy": -1}))
    assert len(a.changes(snap({"dxy": 1}))) == 1
    clock.t += dt.timedelta(hours=1)
    assert a.changes(snap({"dxy": -1})) == []           # flip back inside 12h is held
    clock.t += dt.timedelta(hours=12)
    assert len(a.changes(snap({"dxy": -1}))) == 1       # still different later, so it fires


def test_stale_or_demo_readings_never_alert(tmp_path):
    a = make(tmp_path)
    a.changes(snap({"mon": -2, "liq": -1}))
    assert a.changes(snap({"mon": 0, "liq": 0}, stale=("mon", "liq"))) == []
    assert a.changes(snap({"mon": 0}, source="none")) == []


def test_trigger_change(tmp_path):
    a = make(tmp_path)
    a.changes(snap({"mon": -2}))
    assert a.changes(snap({"mon": -2}, trigger="go")) == ["Big-move trigger: Wait to Go"]


def test_send_posts_to_telegram_and_handles_failure(tmp_path):
    http = FakeHttp()
    a = make(tmp_path, http=http)
    a.url = "https://example.up.railway.app/macro/"
    assert asyncio.run(a.send("hi")) is True
    url, body = http.posts[0]
    assert url == "https://api.telegram.org/bot123:abc/sendMessage"
    assert body["chat_id"] == "42" and body["text"].endswith("/macro/")
    assert asyncio.run(make(tmp_path, http=FakeHttp(401)).send("hi")) is False


def test_unconfigured_does_nothing(tmp_path):
    http = FakeHttp()
    a = make(tmp_path, http=http, token="", chat="")
    assert not a.configured
    assert asyncio.run(a.check(snap({"mon": -2}))) == []
    assert http.posts == [] and not (tmp_path / "macro_alerts.json").exists()


def test_check_sends_one_batched_message(tmp_path):
    http = FakeHttp()
    a = make(tmp_path, http=http)
    asyncio.run(a.check(snap({"mon": -2, "dxy": -1})))
    asyncio.run(a.check(snap({"mon": 0, "dxy": 1}, tag="Split market")))
    assert len(http.posts) == 1
    text = http.posts[0][1]["text"]
    assert "Monetary policy" in text and "US dollar" in text and "Regime" in text
