"""Offline tests: FRED and Treasury are replaced by httpx.MockTransport, so nothing touches the network."""
import datetime as dt
import json

import httpx
import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from canary.macro import engine, scoring
from canary.macro.providers import Obs, ProviderError, FredClient, scale_to_billions, tga_closing_balance
from canary.macro.router import router, set_service
from canary.macro.service import MacroService

TODAY = dt.date.today()


def series(values, step_days, end=None):
    """Evenly spaced observations ending at `end` (default: a few days ago)."""
    end = end or TODAY - dt.timedelta(days=2)
    n = len(values)
    return [Obs(end - dt.timedelta(days=step_days * (n - 1 - i)), float(v)) for i, v in enumerate(values)]


def lin(a, b, n):
    return [a + (b - a) * i / (n - 1) for i in range(n)]


def tight_world() -> dict:
    """Synthetic data resembling a hawkish, strong-dollar, draining-liquidity market."""
    return {
        "DFEDTARU": series([4.0] * 120, 1), "DFEDTARL": series([3.75] * 120, 1), "DFF": series([3.88] * 120, 1),
        "DGS2": series([4.5] * 120, 1),                       # 2y 0.62 above fed funds: hikes priced
        "PCEPILFE": series(lin(100, 104.2, 15), 30),          # ~3.5% y/y
        "CPIAUCSL": series(lin(100, 103.7, 15), 30), "CPILFESL": series(lin(100, 102.6, 15), 30),
        "UNRATE": series([4.2] * 15, 30), "PAYEMS": series([158000 + 120 * i for i in range(10)], 30),
        "DTWEXBGS": series(lin(120, 125, 120), 1),            # about +3% in 90d
        "M2SL": series(lin(21800, 23000, 15), 30),            # ~5.5% y/y
        "WALCL": series([6700 + i for i in range(10)], 7), "TGA": series([850 + 12 * i for i in range(10)], 7),
        "RRPONTSYD": series([300] * 10, 7), "NFCI": series([-0.5 + 0.01 * i for i in range(10)], 7),
        "ECBASSETSW": series(lin(6000, 5900, 20), 7), "JPNASSETS": series(lin(7000, 6900, 20), 7),
        "MTSDS133FMS": series([-150000] * 12 + [-170000] * 12, 30),
        "GDP": series([30000, 30500], 90), "GDPC1": series([23000, 23150], 90), "TOTLL": series(lin(12000, 12700, 60), 7),
        "VIXCLS": series([18] * 20, 1), "BAMLH0A0HYM2": series(lin(2.8, 3.4, 120), 1), "SP500": series(lin(7000, 7400, 60), 1),
    }


# ---- engine ----------------------------------------------------------------------------------

SNAP = {"mon": -2, "dat": -1, "dxy": -1, "m2": 0, "liq": -1, "fis": 1, "tax": 1}


def test_engine_matches_published_snapshot():
    a = engine.analyze(SNAP)
    assert a["net"] == -34 and a["regime_key"] == "tiltTight" and a["same"] == 4
    assert a["trigger"] == "wait" and a["passed"] == 2 and a["divergence"] is True


def test_engine_strong_scenarios():
    e = engine.analyze(engine.SCENARIOS[0]["scores"])
    t = engine.analyze(engine.SCENARIOS[1]["scores"])
    assert (e["regime_key"], e["trigger"]) == ("strongEase", "go")
    assert (t["regime_key"], t["trigger"]) == ("strongTight", "go")


def test_engine_credit_check_can_block_go():
    ok = engine.analyze(engine.SCENARIOS[0]["scores"], credit_widening=-0.2)
    bad = engine.analyze(engine.SCENARIOS[0]["scores"], credit_widening=1.0)
    assert ok["total"] == 6 and ok["trigger"] == "go"
    assert bad["trigger"] == "go"  # 5 of 6 still passes the go bar
    assert bad["passed"] == 5 and ok["passed"] == 6


@pytest.mark.parametrize("bad", [{"mon": 3}, {"mon": True}, {"mon": 1.5}])
def test_engine_rejects_bad_scores(bad):
    with pytest.raises(ValueError):
        engine.analyze({**SNAP, **bad})


def test_engine_rejects_missing_and_unknown():
    with pytest.raises(ValueError):
        engine.analyze({"mon": 1})
    with pytest.raises(ValueError):
        engine.analyze({**SNAP, "zzz": 1})


# ---- scoring ---------------------------------------------------------------------------------

def test_scoring_tight_world():
    S = tight_world()
    assert scoring.monetary(S).score == -2
    assert scoring.economic_data(S).score == -2           # core PCE ~3.4%
    assert scoring.dollar(S).score == -2
    assert scoring.money_supply(S).score == 0
    liq = scoring.global_liquidity(S)
    assert liq.score <= -1
    assert scoring.fiscal(S).score >= 1                   # ~6.4% of GDP, widening


def test_money_supply_thresholds():
    assert scoring.money_supply({"M2SL": series(lin(100, 109, 15), 30)}).score == 2
    assert scoring.money_supply({"M2SL": series(lin(100, 99, 15), 30)}).score == -2


def test_monetary_recent_cut_forces_ease():
    S = tight_world()
    S["DFEDTARU"] = series([4.25] * 60 + [4.0] * 60, 1)   # a cut inside the last 90 days, even though the 2y still says hikes
    assert scoring.monetary(S).score >= 1


def test_insufficient_data_raises():
    with pytest.raises(scoring.InsufficientData):
        scoring.dollar({"DTWEXBGS": series([100, 101], 1)})


def test_manual_factor_goes_stale():
    old = {"score": 1, "note": "x" * 10, "updated": (TODAY - dt.timedelta(days=90)).isoformat()}
    d = scoring.tax_dereg({}, old).to_dict(TODAY)
    assert d["stale"] is True and d["confidence"] == "Low"


def test_clamp_truncates_toward_zero():
    assert scoring.clamp(1.75) == 1 and scoring.clamp(-1.75) == -1 and scoring.clamp(5) == 2


# ---- providers -------------------------------------------------------------------------------

def mock_http(fred_ok=True, tga_ok=True, yahoo_ok=True):
    world = tight_world()
    units = {"WALCL": "Millions of U.S. Dollars", "WTREGEN": "Millions of U.S. Dollars", "RRPONTSYD": "Billions of U.S. Dollars"}

    def handler(req: httpx.Request) -> httpx.Response:
        url = str(req.url)
        if "query1.finance.yahoo.com" in url:
            if not yahoo_ok:
                return httpx.Response(429)
            now = dt.datetime.now(dt.timezone.utc)
            days = [now - dt.timedelta(days=250 - i) for i in range(251)]
            base = 99.0 if "DX-Y" in url else 100.0
            closes = [base + (3.0 * i / 250 if "DX-Y" in url else 0.0) for i in range(251)]  # DXY +~2.9% over 90d
            return httpx.Response(200, json={"chart": {"result": [{
                "meta": {"regularMarketPrice": closes[-1], "regularMarketTime": int(now.timestamp())},
                "timestamp": [int(d.timestamp()) for d in days],
                "indicators": {"quote": [{"close": closes}]}}]}})
        if "api.stlouisfed.org/fred/series/observations" in url:
            sid = req.url.params["series_id"]
            if not fred_ok or sid not in world and sid not in ("WTREGEN",):
                return httpx.Response(400, json={"error_message": "bad"})
            obs = world.get(sid) or [Obs(o.date, o.value * 1000) for o in world["TGA"]]
            if sid == "WALCL":
                obs = [Obs(o.date, o.value * 1000) for o in obs]   # FRED serves millions
            if sid == "WTREGEN":
                obs = [Obs(o.date, o.value * 1000) for o in world["TGA"]]
            return httpx.Response(200, json={"observations": [{"date": o.date.isoformat(), "value": str(o.value)} for o in obs] + [{"date": "2020-01-01", "value": "."}]})
        if "api.stlouisfed.org/fred/series" in url:
            return httpx.Response(200, json={"seriess": [{"units": units[req.url.params["series_id"]]}]})
        if "operating_cash_balance" in url:
            if not tga_ok:
                return httpx.Response(503)
            rows = [{"record_date": o.date.isoformat(), "account_type": "TGA", "open_today_bal": "null", "close_today_bal": str(o.value * 1000)} for o in world["TGA"]]
            return httpx.Response(200, json={"data": rows})
        return httpx.Response(404)

    return httpx.AsyncClient(transport=httpx.MockTransport(handler))


async def test_fred_skips_missing_values_and_hides_key():
    async with mock_http() as http:
        obs = await FredClient("SECRETKEY00000000000000000000000", http).observations("DFF")
        assert len(obs) == 120 and all(isinstance(o.value, float) for o in obs)
    async with mock_http(fred_ok=False) as http:
        with pytest.raises(ProviderError) as e:
            await FredClient("SECRETKEY00000000000000000000000", http).observations("DFF")
        assert "SECRETKEY00000000000000000000000" not in str(e.value) and "api_key" not in str(e.value)


async def test_tga_parses_millions_to_billions():
    async with mock_http() as http:
        obs = await tga_closing_balance(http)
        assert 800 < obs[0].value < 1000


def test_scale_units():
    assert scale_to_billions("Millions of U.S. Dollars") == 0.001
    assert scale_to_billions("Billions of U.S. Dollars") == 1
    with pytest.raises(ProviderError):
        scale_to_billions("Index")


# ---- service + API ---------------------------------------------------------------------------

@pytest.fixture
def client(tmp_path):
    svc = MacroService(http=mock_http(), api_key="k"*32, data_dir=tmp_path, refresh_minutes=999)
    set_service(svc)
    app = FastAPI()
    app.include_router(router)
    with TestClient(app) as c:
        yield c, svc
    set_service(None)


def test_snapshot_end_to_end(client):
    c, svc = client
    r = c.get("/macro/snapshot")
    assert r.status_code == 200
    j = r.json()
    ids = [f["id"] for f in j["factors"]]
    assert ids == ["mon", "dat", "dxy", "m2", "liq", "fis", "tax"]
    assert j["status"]["ok"], j["status"]["errors"]
    assert j["analysis"]["direction"] == "tight"
    assert j["credit_widening"] is not None and j["scenarios"][0]["k"] == "live"
    liq = next(f for f in j["factors"] if f["id"] == "liq")
    assert liq["readings"][0][1].startswith("$6.")   # WALCL scaled from millions to $T


def test_snapshot_survives_provider_failure(tmp_path):
    svc = MacroService(http=mock_http(fred_ok=False, tga_ok=False), api_key="k"*32, data_dir=tmp_path)
    set_service(svc)
    app = FastAPI(); app.include_router(router)
    with TestClient(app) as c:
        j = c.get("/macro/snapshot").json()
    set_service(None)
    assert j["status"]["ok"] is False
    tax = next(f for f in j["factors"] if f["id"] == "tax")
    assert tax["score"] == 1                             # manual factor still works
    mon = next(f for f in j["factors"] if f["id"] == "mon")
    assert mon["score"] == 0 and mon["confidence"] == "None"
    assert "api_key" not in json.dumps(j["status"]["errors"])


def test_missing_api_key_reports_setup(tmp_path):
    svc = MacroService(http=mock_http(), api_key="", data_dir=tmp_path)
    set_service(svc)
    app = FastAPI(); app.include_router(router)
    with TestClient(app) as c:
        j = c.get("/macro/snapshot").json()
    set_service(None)
    assert "setup" in j["status"]["errors"] and "FRED_API_KEY" in j["status"]["errors"]["setup"]


def test_analyze_endpoint_validates(client):
    c, _ = client
    ok = c.post("/macro/analyze", json={"scores": SNAP})
    assert ok.status_code == 200 and ok.json()["net"] == -34
    assert c.post("/macro/analyze", json={"scores": {**SNAP, "mon": 9}}).status_code == 422


def test_admin_endpoints_need_token(client, monkeypatch):
    c, _ = client
    monkeypatch.delenv("MACRO_ADMIN_TOKEN", raising=False)
    assert c.post("/macro/refresh").status_code == 503
    monkeypatch.setenv("MACRO_ADMIN_TOKEN", "s3cret")
    assert c.post("/macro/refresh").status_code == 401
    assert c.post("/macro/refresh", headers={"X-Admin-Token": "wrong"}).status_code == 401
    assert c.post("/macro/refresh", headers={"X-Admin-Token": "s3cret"}).status_code == 200
    r = c.put("/macro/manual/tax", json={"score": 2, "note": "Basel final rule published"}, headers={"X-Admin-Token": "s3cret"})
    assert r.status_code == 200 and r.json()["score"] == 2
    tax = next(f for f in c.get("/macro/snapshot").json()["factors"] if f["id"] == "tax")
    assert tax["score"] == 2
    assert c.put("/macro/manual/tax", json={"score": 5, "note": "nope nope"}, headers={"X-Admin-Token": "s3cret"}).status_code == 422


def test_history_written_once_per_day(client, monkeypatch):
    c, svc = client
    c.get("/macro/snapshot")
    monkeypatch.setenv("MACRO_ADMIN_TOKEN", "t")
    c.post("/macro/refresh", headers={"X-Admin-Token": "t"})
    h = c.get("/macro/history").json()
    assert len(h) == 1 and h[0]["date"] == TODAY.isoformat()


def test_dashboard_page_served(client):
    c, _ = client
    r = c.get("/macro/")
    assert r.status_code == 200 and "CANARY" in r.text


# ---- live market quotes ----------------------------------------------------------------------

async def test_yahoo_quote_parses_and_uses_live_price():
    from canary.macro.providers import yahoo_quote
    async with mock_http() as http:
        q = await yahoo_quote(http, "DX-Y.NYB")
        assert q.closes[-1].value == q.price and q.prev_close < q.price
        assert (dt.datetime.now(dt.timezone.utc) - q.time).total_seconds() < 60
    async with mock_http(yahoo_ok=False) as http:
        with pytest.raises(ProviderError) as e:
            await yahoo_quote(http, "^GSPC")
        assert "429" in str(e.value)


def test_dollar_prefers_live_dxy_and_falls_back_to_fred():
    S = tight_world()
    S["DXY_LIVE"] = series(lin(98, 104, 200), 1, end=TODAY)         # about +2.7% in 90 days
    live = scoring.dollar(S).to_dict(TODAY)
    assert live["readings"][0][0] == "ICE DXY (live)" and live["score"] == -2 and not live["stale"]
    del S["DXY_LIVE"]
    fb = scoring.dollar(S).to_dict(TODAY)
    assert fb["readings"][0][0].startswith("Broad USD") and "lags" in fb["notes"][0]


async def test_snapshot_has_markets_and_freshness(tmp_path):
    svc = MacroService(http=mock_http(), api_key="k" * 32, data_dir=tmp_path)
    snap = await svc.refresh()
    syms = {m["symbol"] for m in snap["markets"]}
    assert {"DX-Y.NYB", "^GSPC", "^VIX", "^TNX", "GC=F", "BTC-USD"} <= syms
    dxy = [f for f in snap["factors"] if f["id"] == "dxy"][0]
    assert dxy["readings"][0][0] == "ICE DXY (live)"
    assert not any(i[0] in ("VIX", "S&P 500") for i in snap["confirmation"])  # tape replaces lagging FRED values
    fr = {r["series"]: r for r in snap["freshness"]}
    assert "CPIAUCSL" in fr and fr["CPIAUCSL"]["age_days"] >= 0 and fr["CPIAUCSL"]["previous"] is not None


async def test_yahoo_outage_keeps_scores_and_reports(tmp_path):
    svc = MacroService(http=mock_http(yahoo_ok=False), api_key="k" * 32, data_dir=tmp_path)
    snap = await svc.refresh()
    assert snap["markets"] == []
    assert snap["status"]["live_factors"] == 6 and "Yahoo ^GSPC" in snap["status"]["errors"]
    dxy = [f for f in snap["factors"] if f["id"] == "dxy"][0]
    assert dxy["readings"][0][0].startswith("Broad USD")
    assert any(i[0] == "VIX" for i in snap["confirmation"])           # falls back to the FRED values
