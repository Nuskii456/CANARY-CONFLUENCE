"""Build the static dashboard for GitHub Pages.

Run from apps/api:  python scripts/build_site.py
Reads FRED_API_KEY (and optional TELEGRAM_* variables) from the environment, refreshes every factor once,
and writes site/ (the page, snapshot.json, history.json, engine.json). State that must survive between runs
(history, alert state, the analyst tax score) lives in data/ and is committed back to the repo by the workflow.

MACRO_DEMO=1 builds from synthetic data so you can test the page without a key.
Exit code 1 means too few live factors loaded; the workflow then keeps the previous site instead of publishing a broken one.
"""
from __future__ import annotations

import asyncio
import json
import os
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from canary.macro import engine  # noqa: E402
from canary.macro.service import MacroService  # noqa: E402

STATIC = ROOT / "canary" / "macro" / "static"
SITE = Path(os.environ.get("MACRO_SITE_DIR", ROOT / "site"))
DATA = Path(os.environ.get("MACRO_DATA_DIR", ROOT / "data"))
MIN_LIVE = 5  # of 7 factors


async def main() -> int:
    demo = os.environ.get("MACRO_DEMO") == "1"
    if demo:
        from tests.test_macro import mock_http
        svc = MacroService(http=mock_http(), api_key="d" * 32, data_dir=DATA, demo=True)
    else:
        svc = MacroService(data_dir=DATA)
    snap = await svc.refresh()
    await svc._http.aclose()

    live = snap["status"]["live_factors"]
    print(f"live factors: {live}/7; errors: {len(snap['status']['errors'])}")
    for k, v in list(snap["status"]["errors"].items())[:8]:
        print(f"  {k}: {v}")
    if live < MIN_LIVE and not demo:
        print("Too few factors loaded; not publishing.", file=sys.stderr)
        return 1

    if SITE.exists():
        shutil.rmtree(SITE)
    SITE.mkdir(parents=True)
    for f in STATIC.iterdir():
        if f.name != "index.html":
            shutil.copy(f, SITE / f.name)
    html = (STATIC / "index.html").read_text(encoding="utf-8")
    html = html.replace('<meta name="theme-color"', '<meta name="canary-static" content="1">\n<meta name="theme-color"', 1)
    (SITE / "index.html").write_text(html, encoding="utf-8")
    (SITE / "snapshot.json").write_text(json.dumps(snap), encoding="utf-8")
    (SITE / "history.json").write_text(json.dumps(svc.history(180)), encoding="utf-8")
    (SITE / "engine.json").write_text(json.dumps({"factors": engine.FACTORS, "playbook": engine.PLAYBOOK}), encoding="utf-8")
    (SITE / ".nojekyll").write_text("")
    print(f"site written to {SITE}")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
